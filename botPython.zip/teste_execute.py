from Entities.fbl1n import FBL1N
from Entities.cod_extrator import CodExtrator, Codigo
from Entities.sharepoint import SharePoint
from datetime import datetime

        
if __name__ == "__main__":
    #codes = CodExtrator().folder(r"R:\Conector APP reten tecnica - consulta SAP fin\#material\Arquivos")
    
    #codes = FBL1N().consultar_pagamentos(codes=codes, delete_plan_excel=False)
    
    bot = SharePoint()

    
    import pdb;pdb.set_trace()
    
    d = datetime.strftime(datetime(2024,10,16),"%Y/%m/%d")
    
    bot.alterar("361", coluna='ConclusaoFinanceiro', valor='16/10/2024')
    